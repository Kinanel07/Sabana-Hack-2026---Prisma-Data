"""Recorta las flores de las fotos (fondo transparente).
Uso, dentro de rosas_vr:  pip install "rembg[cpu]"   y luego   python recortar_flores.py
La primera vez descarga un modelo (internet). Despues funciona sin red.
Entrada: carpeta fotos/   Salida: carpeta fotos_recortadas/ (PNG)."""
from pathlib import Path
from PIL import Image
from rembg import remove, new_session

entrada, salida = Path("fotos"), Path("fotos_recortadas")
salida.mkdir(exist_ok=True)
sesion = new_session("u2net")
for f in sorted(entrada.glob("*.jpg")):
    recorte = remove(Image.open(f).convert("RGB"), session=sesion)
    caja = recorte.getbbox()
    if caja:
        recorte = recorte.crop(caja)
    recorte.save(salida / (f.stem + ".png"))
    print("listo:", f.name)
