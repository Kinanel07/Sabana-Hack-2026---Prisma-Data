"""
servidor.py - Sirve la escena (escena.html, aframe.min.js) y transcribe la voz con Whisper.

Uso (dentro de la carpeta rosas_vr):
    python servidor.py
Luego abrir:  http://localhost:8000/escena.html
Whisper debe estar ya en la cache de Hugging Face; despues funciona sin red.

Datos: datos/respuestas.csv, datos/sesiones.csv y datos/cortes.csv (se crean al arrancar).
Registro en la nube (opcional, Google Sheets): ver apps_script_hoja.gs. Se activa con dos variables de entorno:
    set URL_HOJA=https://script.google.com/macros/s/XXXX/exec
    set TOKEN_HOJA=la_misma_clave_que_puso_en_el_script
Siempre se guarda primero el CSV local (datos/*.csv); si no hay internet, los datos quedan en
datos/pendientes_hoja.jsonl y se envian solos cuando vuelva la conexion.
"""
import os
import re
import tempfile
import unicodedata
from pathlib import Path

import uvicorn
from fastapi import FastAPI, File, UploadFile
from fastapi.staticfiles import StaticFiles
from fastapi.responses import Response
from fastapi import Request
import csv
import threading
import datetime
import io
import json
import time
import urllib.request
import wave
from faster_whisper import WhisperModel

BASE = Path(__file__).resolve().parent
PUERTO = int(os.environ.get("PUERTO", "8000"))
HOST = os.environ.get("HOST", "127.0.0.1")           # "0.0.0.0" si el visor (Quest) se conecta por la red del PC
MODELO = os.environ.get("WHISPER_MODELO", "small")   # "base" si va lento

print(f"Cargando Whisper '{MODELO}' (puede tardar unos segundos)...")
whisper = WhisperModel(MODELO, device="cpu", compute_type="int8")

# Calentamiento: la primera transcripcion siempre es la mas lenta
try:
    import numpy as np
    list(whisper.transcribe(np.zeros(16000, dtype="float32"), language="es", beam_size=1)[0])
except Exception as e:
    print("(calentamiento omitido:", e, ")")
print("Whisper listo.")

PALABRAS_SI = {"si", "sip", "sii", "seh", "claro", "correcto", "lista", "listo",
               "cortar", "cortarla", "corte", "afirmativo", "exacto"}
PALABRAS_NO = {"no", "todavia", "aun", "falta", "negativo", "esperar", "espera", "verde"}


def normalizar(texto: str) -> list[str]:
    t = unicodedata.normalize("NFD", texto.lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")   # quita tildes
    return re.findall(r"[a-z]+", t)


def interpretar(texto: str):
    """Devuelve 'si', 'no' o None. Si aparece alguna palabra negativa, gana 'no'."""
    palabras = set(normalizar(texto))
    if palabras & PALABRAS_NO:
        return "no"
    if palabras & PALABRAS_SI:
        return "si"
    return None


def transcribir_archivo(ruta: str, con_vad: bool) -> str:
    # Sin initial_prompt y con los filtros de Whisper activos: con silencio, Whisper
    # puede repetir el prompt ("...si o no") y eso se leeria como una respuesta falsa.
    opciones = dict(language="es", beam_size=1, condition_on_previous_text=False)
    if con_vad:
        opciones.update(vad_filter=True, vad_parameters=dict(min_silence_duration_ms=500, speech_pad_ms=300))
    segmentos, _ = whisper.transcribe(ruta, **opciones)
    return " ".join(s.text for s in segmentos).strip()


# ---- Voz de Piper (opcional): si falta, la escena usa la voz del navegador ----
VOZ_PIPER = os.environ.get("VOZ_PIPER", str(BASE / "voces" / "es_MX-claude-high.onnx"))
_voz = None
_cache = {}


def cargar_voz():
    global _voz
    if _voz is None and Path(VOZ_PIPER).exists():
        from piper import PiperVoice
        _voz = PiperVoice.load(VOZ_PIPER)
    return _voz


try:
    print("Voz Piper lista." if cargar_voz() else f"Sin voz Piper (no existe {VOZ_PIPER}); se usara la voz del navegador.")
except Exception as e:
    print("Piper no disponible:", e)

app = FastAPI()


@app.get("/api/voz")
def voz(texto: str):
    if texto in _cache:
        return Response(_cache[texto], media_type="audio/wav")
    try:
        v = cargar_voz()
        if v is None:
            return Response(status_code=404)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            v.synthesize_wav(texto, wf)
        _cache[texto] = buf.getvalue()
        return Response(_cache[texto], media_type="audio/wav")
    except Exception as e:
        print("Error de voz:", e)
        return Response(status_code=500)


@app.post("/api/transcribir")
async def transcribir(audio: UploadFile = File(...)):
    datos = await audio.read()
    (BASE / "ultimo_audio.webm").write_bytes(datos)   # para escuchar lo que llego (diagnostico)
    print(f"Audio recibido: {len(datos)} bytes")
    with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as f:
        f.write(datos)
        ruta = f.name
    texto = ""
    try:
        try:
            texto = transcribir_archivo(ruta, con_vad=True)
        except Exception as e:
            print("VAD no disponible, sigo sin el:", e)
        if not texto:   # el VAD pudo recortar una palabra muy corta: segundo intento sin VAD
            texto = transcribir_archivo(ruta, con_vad=False)
    except Exception as e:
        print("Error al transcribir:", e)
        texto = ""
    finally:
        os.remove(ruta)
    respuesta = interpretar(texto)
    print(f"Escuche: {texto!r} -> {respuesta}")
    return {"texto": texto, "respuesta": respuesta}


# ---- Datos de rendimiento: CSV en la carpeta datos/ (se abren con Excel) ----
DATOS = BASE / "datos"
DATOS.mkdir(exist_ok=True)
_lock = threading.Lock()
CAMPOS_RESP = ["sesion", "trabajador", "celular", "flor", "foto", "respuesta", "correcta", "acierto", "via", "texto_oido", "segundos", "intentos_voz"]
CAMPOS_SES = ["sesion", "trabajador", "celular", "aciertos", "total", "porcentaje", "duracion_s", "cortes_tempranos",
              "flores_dejadas_pasar", "falladas", "plan_entregado"]
CAMPOS_CORTE = ["sesion", "trabajador", "celular", "intento", "zona", "acierto", "segundos", "via"]   # practica de corte (verde/amarilla/roja)


def limpiar(v):
    """Evita que Excel/Sheets ejecuten como formula un texto escrito por el usuario (=, +, -, @)."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") and not re.fullmatch(r"-?\d+(\.\d+)?", v):
        return "'" + v
    return v


def _escribir(ruta, todos, fila):
    nuevo = not ruta.exists()
    with _lock, open(ruta, "a", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=todos)
        if nuevo:
            w.writeheader()
        w.writerow(fila)


def anotar(archivo, campos, fila):
    ruta = DATOS / archivo
    todos = ["fecha_hora"] + campos
    fila = {"fecha_hora": datetime.datetime.now().isoformat(timespec="seconds"), **fila}
    fila = {k: limpiar(fila.get(k, "")) for k in todos}
    try:
        _escribir(ruta, todos, fila)
    except PermissionError:
        # Pasa si el CSV esta abierto en Excel: se guarda en un archivo de respaldo para no perder el dato
        respaldo = DATOS / (ruta.stem + "_respaldo.csv")
        print(f"!!! No se pudo escribir en {ruta.name} (cierre Excel). Se guardo en {respaldo.name}")
        _escribir(respaldo, todos, fila)
    print(f"Guardado en datos/{archivo}")
    return fila


def asegurar_csv(archivo, campos):
    """Crea el CSV con sus encabezados al arrancar, para que la carpeta datos/ nunca quede vacia."""
    ruta = DATOS / archivo
    if not ruta.exists():
        with open(ruta, "w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f).writerow(["fecha_hora"] + campos)


for _a, _c in (("respuestas.csv", CAMPOS_RESP), ("sesiones.csv", CAMPOS_SES), ("cortes.csv", CAMPOS_CORTE)):
    asegurar_csv(_a, _c)


# ---- Envio a Google Sheets (opcional) ----
URL_HOJA = os.environ.get("URL_HOJA", "").strip()
TOKEN_HOJA = os.environ.get("TOKEN_HOJA", "").strip()
PENDIENTES = DATOS / "pendientes_hoja.jsonl"
_lock_p = threading.Lock()


def enviar_a_hoja(item) -> bool:
    cuerpo = json.dumps({**item, "token": TOKEN_HOJA}).encode("utf-8")
    req = urllib.request.Request(URL_HOJA, data=cuerpo, headers={"Content-Type": "text/plain; charset=utf-8"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:    # Google responde con un redireccionamiento; urllib lo sigue
            resp = r.read().decode("utf-8", "ignore")
        return '"ok":true' in resp.replace(" ", "")
    except Exception as e:
        print("Hoja de calculo: no se pudo enviar ahora (", e, ") - se reintenta luego")
        return False


def encolar_hoja(tipo, fila, id_):
    if not URL_HOJA:
        return
    with _lock_p, open(PENDIENTES, "a", encoding="utf-8") as f:
        f.write(json.dumps({"tipo": tipo, "fila": {"id": id_, **fila}}, ensure_ascii=False) + "\n")


def vaciar_pendientes():
    with _lock_p:
        if not PENDIENTES.exists():
            return
        lineas = [l for l in PENDIENTES.read_text(encoding="utf-8").splitlines() if l.strip()]
        quedan = []
        for i, l in enumerate(lineas):
            if enviar_a_hoja(json.loads(l)):
                continue
            quedan = lineas[i:]      # si falla uno, se corta (probablemente no hay internet) y se conserva el resto en orden
            break
        PENDIENTES.write_text("".join(x + "\n" for x in quedan), encoding="utf-8")


def bucle_hoja():
    while True:
        try:
            vaciar_pendientes()
        except Exception as e:
            print("Error enviando a la hoja:", e)
        time.sleep(5)


if URL_HOJA:
    threading.Thread(target=bucle_hoja, daemon=True).start()
    print("Envio a Google Sheets ACTIVADO.")
else:
    print("Envio a Google Sheets desactivado (falta URL_HOJA). Los datos se guardan solo en datos/*.csv")


@app.post("/api/registro")
async def registro(req: Request):
    fila = anotar("respuestas.csv", CAMPOS_RESP, await req.json())
    encolar_hoja("respuestas", fila, f"{fila['sesion']}-{fila['flor']}")
    return {"ok": True}


@app.post("/api/sesion")
async def sesion(req: Request):
    fila = anotar("sesiones.csv", CAMPOS_SES, await req.json())
    encolar_hoja("sesiones", fila, str(fila["sesion"]))
    return {"ok": True}


@app.post("/api/corte")
async def corte(req: Request):
    fila = anotar("cortes.csv", CAMPOS_CORTE, await req.json())
    encolar_hoja("cortes", fila, f"{fila['sesion']}-corte-{fila['intento']}")
    return {"ok": True}


@app.get("/api/cortes")
def cortes():
    ruta = DATOS / "cortes.csv"
    if not ruta.exists():
        return {"cortes": []}
    with open(ruta, newline="", encoding="utf-8-sig") as f:
        return {"cortes": list(csv.DictReader(f))}


@app.get("/api/resumen")
def resumen():
    ruta = DATOS / "sesiones.csv"
    if not ruta.exists():
        return {"sesiones": []}
    with open(ruta, newline="", encoding="utf-8-sig") as f:
        return {"sesiones": list(csv.DictReader(f))}


# Archivos estaticos (escena.html, aframe.min.js, fotos...). Debe ir despues de las rutas /api.
app.mount("/", StaticFiles(directory=BASE, html=True), name="static")

if __name__ == "__main__":
    uvicorn.run(app, host=HOST, port=PUERTO)
