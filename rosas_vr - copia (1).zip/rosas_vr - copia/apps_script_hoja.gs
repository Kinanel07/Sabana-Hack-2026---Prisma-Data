/**
 * Recibe los resultados de la capacitación y los agrega como filas a la hoja de cálculo.
 *
 * PASOS (una sola vez):
 *  1. Cree una hoja nueva en https://sheets.google.com  (por ejemplo "Capacitacion rosas").
 *  2. Menú Extensiones > Apps Script. Borre lo que haya y pegue TODO este archivo.
 *  3. Cambie CLAVE por una palabra secreta larga (la misma que pondrá en TOKEN_HOJA en el PC).
 *  4. Implementar > Nueva implementación > tipo "Aplicación web".
 *       Ejecutar como: Yo      |      Quién tiene acceso: Cualquier persona
 *     Autorice los permisos y copie la URL que termina en /exec  (esa es URL_HOJA).
 *  5. Si cambia este código después, use Implementar > Administrar implementaciones > Editar > Nueva versión.
 *
 * Se crean solas dos pestañas: "respuestas" (una fila por rosa) y "sesiones" (una fila por trabajador y práctica).
 * Cada fila trae un "id" y no se repite aunque el PC reenvíe los datos.
 */
const CLAVE = "CAMBIE_ESTA_CLAVE";

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const d = JSON.parse(e.postData.contents);
    if (d.token !== CLAVE) return salida({ ok: false, error: "clave incorrecta" });
    if (d.tipo !== "respuestas" && d.tipo !== "sesiones") return salida({ ok: false, error: "tipo desconocido" });
    lock.waitLock(20000);
    const libro = SpreadsheetApp.getActiveSpreadsheet();
    const hoja = libro.getSheetByName(d.tipo) || libro.insertSheet(d.tipo);
    const campos = Object.keys(d.fila);
    if (hoja.getLastRow() === 0) {
      hoja.appendRow(campos);
      hoja.setFrozenRows(1);
      hoja.getRange(1, 1, 1, campos.length).setFontWeight("bold");
    }
    const cab = hoja.getRange(1, 1, 1, hoja.getLastColumn()).getValues()[0];
    const colId = cab.indexOf("id") + 1;
    if (colId > 0 && hoja.getLastRow() > 1) {
      const ids = hoja.getRange(2, colId, hoja.getLastRow() - 1, 1).getValues().flat().map(String);
      if (ids.indexOf(String(d.fila.id)) !== -1) return salida({ ok: true, repetido: true });
    }
    hoja.appendRow(cab.map(c => (d.fila[c] === undefined ? "" : d.fila[c])));
    return salida({ ok: true });
  } catch (err) {
    return salida({ ok: false, error: String(err) });
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

function salida(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
