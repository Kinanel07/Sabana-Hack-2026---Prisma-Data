// Rosas 3D procedurales (adaptadas del proyecto rose-webxr-quest3 de los companeros).
// Usa el THREE que ya incluye A-Frame: no necesita internet ni otras librerias.
(function(){
  const T = THREE, mats = {};
  const mat = hex => mats[hex] || (mats[hex] = new T.MeshStandardMaterial({color: hex, roughness: 0.6, side: T.DoubleSide}));

  function petalo(w, h, curl, color){
    const g = new T.PlaneGeometry(w, h, 8, 10), p = g.attributes.position;
    for(let i = 0; i < p.count; i++){
      const x = p.getX(i), y = p.getY(i), u = x / w + 0.5, v = y / h + 0.5;
      const edge = Math.pow(Math.abs(u - 0.5) * 2, 1.55);
      p.setZ(i, curl * (v * v * 0.82 + edge * 0.25) + Math.sin(u * Math.PI * 3) * 0.018 * v);
    }
    g.computeVertexNormals();
    return new T.Mesh(g, mat(color));
  }
  function sepalo(r, y){
    const s = petalo(r * 0.62, r * 1.25, 0.12, 0x3e7728);
    s.scale.set(0.76, 1, 1); s.position.y = y; s.rotation.x = 0.52; return s;
  }
  function tallo(h){
    const st = new T.Group();
    const b = new T.Mesh(new T.CylinderGeometry(0.075, 0.095, h, 10, 1), mat(0x28581e));
    b.position.y = h / 2; st.add(b);
    [0.67, 1.28].forEach((y, i) => {
      const l = petalo(0.48, 0.78, 0.08, 0x2d6b2a);
      l.scale.set(0.75, 1, 1); l.position.set(i ? -0.2 : 0.2, y, 0.02); l.rotation.set(0.42, i ? 2.4 : -0.75, 0); st.add(l);
    });
    return st;
  }

  // Los 3 cortes de los companeros: 0 triangular, 1 alto y estrecho, 2 copa
  const MODELOS = [
    {rings: 4, sil: t => 0.58 * (1 - t) + 0.055, open: 0.10},
    {rings: 5, sil: t => 0.31 - t * 0.08,        open: 0.31},
    {rings: 6, sil: t => 0.56 - t * 0.18,        open: 0.74}
  ];

  window.crearRosa3D = function(modelo, color){
    const M = MODELOS[modelo] || MODELOS[0], rose = new T.Group();
    rose.add(tallo(2.25));
    const head = new T.Group(); head.position.y = 2.25; rose.add(head);
    for(let r = 0; r < M.rings; r++){
      const t = r / Math.max(1, M.rings - 1), count = 5 + r * 2, radius = M.sil(t);
      const y = 0.12 + (1 - t) * 1.1, w = 0.4 + radius * 1.55, h = 0.62 + t * 0.34;
      for(let i = 0; i < count; i++){
        const a = (i / count) * Math.PI * 2 + r * 0.39, g = new T.Group();
        g.position.set(Math.sin(a) * radius, y, Math.cos(a) * radius); g.rotation.y = a;
        const p = petalo(w, h, 0.07 + M.open * 0.18, color);
        p.position.y = h * 0.15; p.rotation.x = M.open * (0.42 + 0.26 * t) + 0.05;
        g.add(p); head.add(g);
      }
    }
    for(let i = 0; i < 9; i++){   // caracol central
      const a = i * 1.76, rad = 0.018 + i * 0.025, g = new T.Group();
      g.position.set(Math.sin(a) * rad, 1.18 + i * 0.018, Math.cos(a) * rad); g.rotation.y = a;
      const p = petalo(0.26 - i * 0.009, 0.42 - i * 0.013, 0.04, color);
      p.rotation.x = 0.04 + M.open * 0.13; g.add(p); head.add(g);
    }
    for(let i = 0; i < 5; i++){   // sepalos
      const g = new T.Group(), a = i / 5 * Math.PI * 2 + 0.25;
      g.position.set(Math.sin(a) * 0.34, 0.14, Math.cos(a) * 0.34); g.rotation.y = a;
      g.add(sepalo(0.54, 0.1)); head.add(g);
    }
    return rose;
  };
})();
